const express = require('express');
const http = require('http');
const path = require('path');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

// Game file (index.html) isi folder se serve hoti hai
app.use(express.static(__dirname));
app.get('/health', (req, res) => res.send('ok'));

const MAX_PER_ROOM = 8; // 4v4
const rooms = {};       // roomCode -> { players: { socketId: {...} } }

io.on('connection', (socket) => {
  let roomCode = null;

  // Client: socket.emit('join', { room:'ABCD', name:'Rahul', team:0 })
  socket.on('join', ({ room, name, team }) => {
    room = String(room || 'MAIN').toUpperCase().slice(0, 12);
    if (!rooms[room]) rooms[room] = { players: {} };
    if (Object.keys(rooms[room].players).length >= MAX_PER_ROOM) {
      socket.emit('room-full');
      return;
    }
    roomCode = room;
    socket.join(room);
    rooms[room].players[socket.id] = {
      id: socket.id,
      name: String(name || 'Soldier').slice(0, 16),
      team: team === 1 ? 1 : 0,
      health: 100,
      pos: { x: 0, y: 0, z: 0 },
      rotY: 0
    };
    // naye player ko current players ki list do
    socket.emit('joined', { id: socket.id, players: rooms[room].players });
    // baaki sabko batao
    socket.to(room).emit('player-joined', rooms[room].players[socket.id]);
  });

  // Position / rotation sync
  socket.on('state', (s) => {
    const p = rooms[roomCode]?.players[socket.id];
    if (!p) return;
    p.pos = s.pos; p.rotY = s.rotY;
    socket.to(roomCode).volatile.emit('state', { id: socket.id, pos: s.pos, rotY: s.rotY });
  });

  // Goli chalna (sirf effect dikhane ke liye)
  socket.on('shoot', (data) => {
    if (roomCode) socket.to(roomCode).emit('shoot', { id: socket.id, ...data });
  });

  // Hit report: { targetId, damage, headshot }
  socket.on('hit', ({ targetId, damage, headshot }) => {
    const room = rooms[roomCode];
    const target = room?.players[targetId];
    const shooter = room?.players[socket.id];
    if (!target || !shooter || target.team === shooter.team) return;
    const dmg = Math.min(Math.max(Number(damage) || 0, 0), 100); // basic cheat limit
    target.health -= dmg;
    io.to(roomCode).emit('health', { id: targetId, health: target.health });
    if (target.health <= 0) {
      io.to(roomCode).emit('kill', { killer: socket.id, victim: targetId, headshot: !!headshot });
      target.health = 100; // respawn simple version
    }
  });

  socket.on('disconnect', () => {
    if (!roomCode || !rooms[roomCode]) return;
    delete rooms[roomCode].players[socket.id];
    socket.to(roomCode).emit('player-left', socket.id);
    if (Object.keys(rooms[roomCode].players).length === 0) delete rooms[roomCode];
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log('Server chal raha hai, port', PORT));
